// PulseOS push backend: serves the app, stores schedules, and sends Web Push on a 1-minute cron.
const enc = new TextEncoder();
const b64u = (b) => btoa(String.fromCharCode(...new Uint8Array(b))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
const unb64u = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), (c) => c.charCodeAt(0));
const sha = async (s) => [...new Uint8Array(await crypto.subtle.digest('SHA-256', enc.encode(s)))].map((x) => x.toString(16).padStart(2, '0')).join('');
const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json' } });

async function authHeader(env, endpoint) {
  const pub = unb64u(env.VAPID_PUBLIC);
  const key = await crypto.subtle.importKey(
    'jwk',
    { kty: 'EC', crv: 'P-256', x: b64u(pub.slice(1, 33)), y: b64u(pub.slice(33, 65)), d: env.VAPID_PRIVATE, ext: true },
    { name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign']);
  const head = b64u(enc.encode(JSON.stringify({ typ: 'JWT', alg: 'ES256' })));
  const body = b64u(enc.encode(JSON.stringify({ aud: new URL(endpoint).origin, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: env.VAPID_SUBJECT })));
  const sig = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, enc.encode(head + '.' + body));
  return `vapid t=${head}.${body}.${b64u(sig)}, k=${env.VAPID_PUBLIC}`;
}

// Empty push: the service worker fetches the message content from /api/pending.
async function push(env, endpoint) {
  const r = await fetch(endpoint, { method: 'POST', headers: { Authorization: await authHeader(env, endpoint), TTL: '120', Urgency: 'high' } });
  return r.status;
}

function local(tz) {
  let f;
  try { f = new Intl.DateTimeFormat('en-US', { timeZone: tz, hour: 'numeric', minute: 'numeric', hourCycle: 'h23', weekday: 'short', year: 'numeric', month: 'numeric', day: 'numeric' }); }
  catch { f = new Intl.DateTimeFormat('en-US', { timeZone: 'UTC', hour: 'numeric', minute: 'numeric', hourCycle: 'h23', weekday: 'short', year: 'numeric', month: 'numeric', day: 'numeric' }); }
  const p = Object.fromEntries(f.formatToParts(new Date()).map((x) => [x.type, x.value]));
  return { mins: +p.hour * 60 + +p.minute, wd: p.weekday, day: `${p.year}-${p.month}-${p.day}` };
}

function due(sub) {
  const L = local(sub.tz), weekend = L.wd === 'Sat' || L.wd === 'Sun', acks = JSON.parse(sub.acks || '[]'), out = [];
  const vibrate = JSON.parse(sub.vibrate || '[200,100,200]');
  for (const t of JSON.parse(sub.tasks || '[]')) {
    if ((t.type === 'weekend' && !weekend) || t.done === L.day) continue;
    const base = { tid: t.id, tag: 'pulseos-' + t.id, vibrate, title: t.title };
    if (sub.lead > 0 && L.mins === (t.start - sub.lead + 1440) % 1440) out.push({ ...base, body: `Starts in ${sub.lead} min` });
    if (L.mins === t.start) out.push({ ...base, body: 'Starting now' });
    if (sub.nag && L.mins > t.start && L.mins <= t.start + 3 && !acks.includes(`${L.day}:${t.id}`)) out.push({ ...base, body: 'Still waiting on you ⏰' });
  }
  return out;
}

export default {
  async scheduled(_ev, env) {
    const { results } = await env.DB.prepare('SELECT * FROM subs').all();
    await Promise.all(results.map(async (sub) => {
      const out = due(sub);
      if (!out.length) return;
      const pending = JSON.parse(sub.pending || '[]').concat(out).slice(-10);
      await env.DB.prepare('UPDATE subs SET pending=? WHERE id=?').bind(JSON.stringify(pending), sub.id).run();
      const st = await push(env, sub.endpoint).catch(() => 0);
      if (st === 404 || st === 410) await env.DB.prepare('DELETE FROM subs WHERE id=?').bind(sub.id).run();
    }));
  },

  async fetch(req, env) {
    const u = new URL(req.url);
    if (!u.pathname.startsWith('/api/')) return env.ASSETS.fetch(req);
    if (u.pathname === '/api/config') return json({ publicKey: env.VAPID_PUBLIC });
    if (req.method !== 'POST') return json({ error: 'method' }, 405);
    let b;
    try { b = await req.json(); } catch { return json({ error: 'bad json' }, 400); }
    const ep = b && b.endpoint;
    if (typeof ep !== 'string' || !ep.startsWith('https://') || ep.length > 1000) return json({ error: 'endpoint' }, 400);
    const id = await sha(ep), DB = env.DB;

    switch (u.pathname) {
      case '/api/sync': {
        const tasks = (Array.isArray(b.tasks) ? b.tasks : []).slice(0, 50).map((t) => ({
          id: String(t.id).slice(0, 40), title: String(t.title || 'Task').slice(0, 80),
          start: Math.max(0, Math.min(1439, t.start | 0)), type: t.type === 'weekend' ? 'weekend' : 'daily', done: String(t.done || '').slice(0, 12) }));
        const vib = (Array.isArray(b.vibrate) ? b.vibrate : [200]).slice(0, 20).map((n) => Math.min(2000, Math.max(0, n | 0)));
        await DB.prepare(`INSERT INTO subs(id,endpoint,tz,lead,nag,vibrate,tasks,updated) VALUES(?,?,?,?,?,?,?,?)
          ON CONFLICT(id) DO UPDATE SET tz=excluded.tz,lead=excluded.lead,nag=excluded.nag,vibrate=excluded.vibrate,tasks=excluded.tasks,updated=excluded.updated`)
          .bind(id, ep, String(b.tz || 'UTC').slice(0, 60), Math.max(0, Math.min(60, b.lead | 0)), b.nag ? 1 : 0, JSON.stringify(vib), JSON.stringify(tasks), Date.now()).run();
        return json({ ok: true });
      }
      case '/api/pending': {
        const row = await DB.prepare('SELECT pending FROM subs WHERE id=?').bind(id).first();
        if (!row) return json({ items: [] });
        await DB.prepare("UPDATE subs SET pending='[]' WHERE id=?").bind(id).run();
        return json({ items: JSON.parse(row.pending || '[]') });
      }
      case '/api/ack': {
        const row = await DB.prepare('SELECT tz,acks FROM subs WHERE id=?').bind(id).first();
        if (row) {
          const a = JSON.parse(row.acks || '[]'); a.push(`${local(row.tz).day}:${String(b.tid)}`);
          await DB.prepare('UPDATE subs SET acks=? WHERE id=?').bind(JSON.stringify(a.slice(-50)), id).run();
        }
        return json({ ok: true });
      }
      case '/api/test': {
        const row = await DB.prepare('SELECT vibrate FROM subs WHERE id=?').bind(id).first();
        if (!row) return json({ error: 'not synced' }, 404);
        const item = { title: 'PulseOS test ✨', body: 'Background alerts are working.', tag: 'pulseos-test', vibrate: JSON.parse(row.vibrate) };
        await DB.prepare('UPDATE subs SET pending=? WHERE id=?').bind(JSON.stringify([item]), id).run();
        return json({ status: await push(env, ep) });
      }
      case '/api/unsubscribe':
        await DB.prepare('DELETE FROM subs WHERE id=?').bind(id).run();
        return json({ ok: true });
    }
    return json({ error: 'not found' }, 404);
  },
};
