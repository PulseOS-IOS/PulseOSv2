# PulseOS with background alerts

Alerts arrive even when the app is closed (Web Push). Free on Cloudflare's free plan.
A parent or guardian should create the Cloudflare account and provide the email below.

## One-time setup (about 10 minutes)
Install Node.js (nodejs.org), then in a terminal inside this folder:

1. `npx wrangler login`
2. `npx wrangler d1 create pulseos`  -> copy the `database_id` into `wrangler.jsonc`
3. `npx wrangler d1 execute pulseos --remote --file=schema.sql`
4. `npx web-push generate-vapid-keys --json`
   - put `publicKey` into `wrangler.jsonc` as `VAPID_PUBLIC`
   - put a parent/guardian email into `VAPID_SUBJECT` as `mailto:name@example.com`
5. `npx wrangler deploy`
6. `npx wrangler secret put VAPID_PRIVATE`  -> paste the `privateKey`

Your app is now live at `https://pulseos.<your-subdomain>.workers.dev`.

## On each phone
- **iPhone (iOS 16.4+):** open the link in Safari, Share -> Add to Home Screen, open PulseOS from the Home Screen.
- **Android:** open in Chrome, menu -> Install app.
- In PulseOS: Settings -> Turn on background alerts -> Send test alert.

## PWA checklist (all included)
- Web app manifest + icons: installable from Safari (Add to Home Screen) and Chrome (Install app)
- Service worker: offline app shell + background push handling
- Push system + scheduler: alerts when the app is closed
- Schedule header has a Phone alerts button (Google/Apple Calendar, Android alarm) as a backup

## Limits
- Alerts use the phone's notification sound. Web apps can't set a custom ringtone, loop an alarm, or bypass Silent mode/Focus.
- Alarm mode repeats the alert up to 3 times until tapped.
- Buttons on notifications and vibration patterns work on Android; iPhone ignores them.
- Alerts can be late by up to about a minute.
